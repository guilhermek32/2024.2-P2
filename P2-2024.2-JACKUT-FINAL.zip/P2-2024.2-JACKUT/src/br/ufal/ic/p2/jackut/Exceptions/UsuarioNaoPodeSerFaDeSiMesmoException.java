package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando tenta-se adicionar como f� de si mesmo.
 */
public class UsuarioNaoPodeSerFaDeSiMesmoException extends RuntimeException {
    public UsuarioNaoPodeSerFaDeSiMesmoException() {
        super("Usu�rio n�o pode ser f� de si mesmo.");
    }
}
