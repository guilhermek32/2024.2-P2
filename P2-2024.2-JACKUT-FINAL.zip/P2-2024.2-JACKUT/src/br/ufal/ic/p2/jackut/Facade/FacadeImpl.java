package br.ufal.ic.p2.jackut.Facade;

import br.ufal.ic.p2.jackut.Exceptions.*;
import br.ufal.ic.p2.jackut.service.*;

/**
 * Classe que implementa a interface IFacade.
 */
public class FacadeImpl implements IFacade {
    private final UsuarioService usuarioService;
    private final SessaoService sessaoService;
    private final ComunidadeService comunidadeService;
    private final MensagemService mensagemService;
    private final SessaoValidator sessaoValidator;

    /**
     * Construtor da classe FacadeImpl.
     * Inicializa os servi�os necess�rios para o funcionamento do sistema.
     */
    public FacadeImpl() {
        this.usuarioService = new UsuarioService();
        this.sessaoService = new SessaoService(usuarioService);
        this.comunidadeService = new ComunidadeService(usuarioService, sessaoService);
        this.mensagemService = new MensagemService(usuarioService, sessaoService, comunidadeService);
        this.sessaoValidator = new SessaoValidator(sessaoService);
    }

    /**
     * Zera o sistema, limpando todos os dados armazenados.
     */
    @Override
    public void zerarSistema() {
        usuarioService.zerar();
        sessaoService.zerar();
        comunidadeService.zerar();
        mensagemService.zerar();
    }

    /**
     * Carrega o estado do sistema a partir dos arquivos JSON.
     */
    @Override
    public void carregarSistema() {
        usuarioService.carregar();
        sessaoService.carregar();
        comunidadeService.carregar();
        mensagemService.carregar();
    }

    /**
     * Encerra o sistema, salvando todos os dados em arquivos JSON.
     */
    @Override
    public void encerrarSistema() {
        usuarioService.salvar();
        comunidadeService.salvar();
        mensagemService.salvar();
    }

    /**
     * Cria um novo usu�rio no sistema.
     * @param login  O login do usu�rio.
     * @param senha  A senha do usu�rio.
     * @param nome   O nome do usu�rio.
     */
    @Override
    public void criarUsuario(String login, String senha, String nome) {
        usuarioService.criarUsuario(login, senha, nome);
    }

    /**
     * Retorna o atributo de um usu�rio.
     * @param login
     * @param atributo
     * @return
     */
    @Override
    public String getAtributoUsuario(String login, String atributo) {
        if (login == null || login.trim().isEmpty()) {
            throw new LoginInvalidoException();
        }
        return usuarioService.getAtributo(login, atributo);
    }

    /**
     * Edita o perfil de um usu�rio.
     * @param sessionId O ID da sess�o do usu�rio.
     * @param atributo  O atributo a ser editado.
     * @param conteudo  O novo conte�do do atributo.
     */
    @Override
    public void editarPerfil(String sessionId, String atributo, String conteudo) {
        String login = sessaoValidator.validarSessao(sessionId);
        usuarioService.editarPerfil(login, atributo, conteudo);
    }

    /**
     * Remove um usu�rio do sistema.
     * @param sessionId
     */
    @Override
    public void removerUsuario(String sessionId) {
        String login = sessaoValidator.validarSessao(sessionId);
        usuarioService.removerUsuario(login);
        comunidadeService.removerUsuario(login);
        mensagemService.removerUsuario(login);
        sessaoService.encerrarSessao(sessionId);
    }

    /**
     * Abre uma sess�o para um usu�rio.
     * @param login
     * @param senha
     * @return
     */
    @Override
    public String abrirSessao(String login, String senha) {
        return sessaoService.abrirSessao(login, senha);
    }

    /**
     * Adiciona um amigo ao dono da sess�o.
     */
    @Override
    public void adicionarAmigo(String sessionId, String amigo) {
        String login = sessaoValidator.validarSessao(sessionId);
        usuarioService.adicionarAmigo(login, amigo);
    }

    /**
     * Verifica se o dono da sess�o � amigo de outro usu�rio.
     * @param usuarioVerificador
     * @param usuarioVerificado
     * @return
     */
    @Override
    public boolean ehAmigo(String usuarioVerificador, String usuarioVerificado) {
        return usuarioService.ehAmigo(usuarioVerificador, usuarioVerificado);
    }

    /**
     * Retorna os amigos do dono da sess�o.
     * @param login
     * @return
     */
    @Override
    public String getAmigos(String login) {
        return usuarioService.getAmigos(login);
    }

    /**
     * Envia um recado para outro usu�rio.
     * @param sessionId
     * @param destinatario
     * @param mensagem
     */
    @Override
    public void enviarRecado(String sessionId, String destinatario, String mensagem) {
        String remetente = sessaoValidator.validarSessao(sessionId);
        if (remetente.equals(destinatario)) {
            throw new UsuarioNaoEnviarRecadoParaSiMesmoException();
        }
        mensagemService.enviarRecado(sessionId, destinatario, mensagem);
    }

    /**
     * L� um recado do dono da sess�o.
     * @param sessionId
     * @return texto do recado lido.
     */
    @Override
    public String lerRecado(String sessionId) {
        try {
            return mensagemService.lerRecado(sessionId);
        } catch (UsuarioNaoCadastradoException e) {
            throw new NaoHaRecadosException();
        }
    }

    /**
     * Cria uma nova comunidade.
     * @param sessionId
     * @param nome
     * @param descricao
     */
    @Override
    public void criarComunidade(String sessionId, String nome, String descricao) {
        comunidadeService.criarComunidade(sessionId, nome, descricao);
    }

    /**
     * Adiciona um usu�rio a uma comunidade existente.
     * @param sessionId
     * @param nome
     */
    @Override
    public void adicionarComunidade(String sessionId, String nome) {
        try {
            comunidadeService.adicionarComunidade(sessionId, nome);
        } catch (LoginOuSenhaInvalidosException e) {
            throw new UsuarioNaoCadastradoException();
        }
    }

    /**
     * Retorna a descri��o da comunidade.
     * @param nome
     * @return descri��o da comunidade.
     */
    @Override
    public String getDescricaoComunidade(String nome) {
        return comunidadeService.getDescricaoComunidade(nome);
    }

    /**
     * Retorna o dono da comunidade.
     * @param nome
     * @return dono da comunidade.
     */
    @Override
    public String getDonoComunidade(String nome) {
        return comunidadeService.getDonoComunidade(nome);
    }

    /**
     * Retorna os membros da comunidade.
     * @param nome
     * @return membros da comunidade.
     */
    @Override
    public String getMembrosComunidade(String nome) {
        return comunidadeService.getMembrosComunidade(nome);
    }

    /**
     * Retorna as comunidades do dono da sess�o.
     * @param identifier
     * @return comunidades do usu�rio.
     */
    @Override
    public String getComunidades(String identifier) {
        try {
            usuarioService.getAtributo(identifier, "senha");
            return comunidadeService.getComunidades(identifier);
        } catch (UsuarioNaoCadastradoException e) {
            String login;
            try {
                login = sessaoService.getLoginPorSessao(identifier);
            } catch (LoginOuSenhaInvalidosException e2) {
                // neither a login nor a valid session
                throw new UsuarioNaoCadastradoException();
            }
            return comunidadeService.getComunidades(login);
        }
    }


    /**
     * Envia uma mensagem para a comunidade.
     * @param sessionId
     * @param nomeComunidade
     * @param texto
     */
    @Override
    public void enviarMensagemComunidade(String sessionId, String nomeComunidade, String texto) {
        mensagemService.enviarMensagemComunidade(sessionId, nomeComunidade, texto);
    }

    /**
     * L� uma mensagem da comunidade do dono da sess�o.
     * @param sessionId
     * @return mensagem lida.
     */
    @Override
    public String lerMensagemComunidade(String sessionId) {
        return mensagemService.lerMensagemComunidade(sessionId);
    }

    /**
     * Adiciona um �dolo ao dono da sess�o.
     * @param sessionId
     * @param idoloLogin
     */
    @Override
    public void adicionarIdolo(String sessionId, String idoloLogin) {
        String login = sessaoValidator.validarSessao(sessionId);
        usuarioService.adicionarIdolo(login, idoloLogin);
    }

    /**
     * Verifica se o dono da sess�o � f� de outro usu�rio.
     * @param login
     * @param idoloLogin
     * @return true se forem f�s, false caso contr�rio.
     */
    @Override
    public boolean ehFa(String login, String idoloLogin) {
        return usuarioService.ehIdolo(login, idoloLogin);
    }

    /**
     * Retorna os f�s de um usu�rio.
     * @param login
     * @return f�s do usu�rio.
     */
    @Override
    public String getFas(String login) {
        return usuarioService.getIdolos(login);
    }

    /**
     * Adiciona um paquera ao dono da sess�o.
     * @param sessionId
     * @param paqueraLogin
     */
    @Override
    public void adicionarPaquera(String sessionId, String paqueraLogin) {
        // Chama o m�todo no MensagemService para adicionar paquera e enviar recados
        mensagemService.adicionarPaqueraESendRecados(sessionId, paqueraLogin);
    }

    /**
     * Verifica se o dono da sess�o � paquera de outro usu�rio.
     * @param sessionId
     * @param paqueraLogin
     * @return true se forem paqueras, false caso contr�rio.
     */
    @Override
    public boolean ehPaquera(String sessionId, String paqueraLogin) {
        String login = sessaoValidator.validarSessao(sessionId);
        return usuarioService.ehPaquera(login, paqueraLogin);
    }

    /**
     * Retorna os paqueras do dono da sess�o.
     * @param sessionId
     * @return os paqueras do usu�rio.
     */
    @Override
    public String getPaqueras(String sessionId) {
        String login = sessaoValidator.validarSessao(sessionId);
        return usuarioService.getPaqueras(login);
    }

    /**
     * Adiciona um inimigo ao dono da sess�o.
     * @param sessionId
     * @param inimigoLogin
     */
    @Override
    public void adicionarInimigo(String sessionId, String inimigoLogin) {
        String login = sessaoValidator.validarSessao(sessionId);
        usuarioService.adicionarInimigo(login, inimigoLogin);
    }

    /**
     * Envia uma mensagem para a comunidade.
     * @param sessionId
     * @param nomeComunidade
     * @param mensagem
     */
    @Override
    public void enviarMensagem(String sessionId, String nomeComunidade, String mensagem) {
        try {
            mensagemService.enviarMensagemComunidade(sessionId, nomeComunidade, mensagem);
        } catch (LoginOuSenhaInvalidosException e) {
            throw new UsuarioNaoCadastradoException();
        }
    }


    /**
     * L� uma mensagem da comunidade do dono da sess�o.
     */
    @Override
    public String lerMensagem(String sessionId) {
        String m = mensagemService.lerMensagemComunidade(sessionId);
        if ("{}".equals(m)) {
            throw new MensagemNaoExisteException();
        }
        return m;
    }
}
