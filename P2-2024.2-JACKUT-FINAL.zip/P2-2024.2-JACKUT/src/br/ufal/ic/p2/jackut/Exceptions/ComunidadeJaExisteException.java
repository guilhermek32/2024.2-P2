package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando uma comunidade j� existe.
 */
public class ComunidadeJaExisteException extends RuntimeException {
    public ComunidadeJaExisteException() {
        super("Comunidade com esse nome j� existe.");
    }
}
