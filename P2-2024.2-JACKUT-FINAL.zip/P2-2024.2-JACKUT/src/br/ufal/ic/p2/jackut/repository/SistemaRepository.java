// src/main/java/br/ufal/ic/p2/jackut/repository/SistemaRepository.java
package br.ufal.ic.p2.jackut.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import br.ufal.ic.p2.jackut.models.Usuario;

import java.io.File;
import java.util.List;

/**
 * Classe respons�vel por gerenciar o armazenamento e recupera��o de dados do sistema.
 * Os dados s�o armazenados em arquivos JSON.
 */
public class SistemaRepository {
    private static final String USUARIOS_JSON = "usuarios.json";
    private final ObjectMapper mapper = new ObjectMapper();


    /**
     * Carrega a lista de usu�rios a partir do arquivo JSON.
     * Se o arquivo n�o existir, retorna uma lista vazia.
     *
     * @return Lista de usu�rios carregados.
     * @throws Exception Se ocorrer um erro ao ler o arquivo JSON.
     */
    public List<Usuario> carregarUsuarios() throws Exception {
        File f = new File(USUARIOS_JSON);
        if (!f.exists()) return List.of();
        return mapper.readValue(f, new TypeReference<List<Usuario>>(){});
    }

    /**
     * Salva a lista de usu�rios no arquivo JSON.
     *
     * @param usuarios Lista de usu�rios a serem salvos.
     * @throws Exception Se ocorrer um erro ao escrever no arquivo JSON.
     */
    public void salvarUsuarios(List<Usuario> usuarios) throws Exception {
        mapper.writerWithDefaultPrettyPrinter()
                .writeValue(new File(USUARIOS_JSON), usuarios);
    }
}