package br.ufal.ic.p2.jackut.models;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.*;

/**
 * Classe que representa um usuário no sistema.
 */
public class Usuario {
    private String login;
    private String senha;
    private String nome;
    private ArrayList<String> friends;
    private ArrayList<String> solicitacoesDeAmizade;
    private Map<String, String> atributos;
    private Queue<Recado> caixaMensagem;
    private Queue<String> mensagensComunidade;
    private List<String> fas;
    private List<String> paqueras;
    private List<String> inimigos;

    public Usuario(){}

    /**
     * Construtor da classe Usuario com parâmetros.
     *
     * @param nome  Nome do usuário.
     * @param login Login do usuário.
     * @param senha Senha do usuário.
     */
    @JsonCreator
    public Usuario(@JsonProperty("nome") String nome, @JsonProperty("login") String login, @JsonProperty("senha") String senha) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.atributos = new HashMap<>();
        this.friends = new ArrayList<>();
        this.solicitacoesDeAmizade = new ArrayList<>();
        this.caixaMensagem = new LinkedList<>();
        this.mensagensComunidade = new LinkedList<>();
        this.fas = new ArrayList<>();
        this.paqueras = new ArrayList<>();
        this.inimigos = new ArrayList<>();
    }

    /**
     * Verifica se a senha fornecida é igual à senha do usuário.
     *
     * @param senha Senha a ser verificada.
     * @return true se a senha for igual, false caso contrário.
     */
    public boolean verificaSenha(String senha) {
        return Objects.equals(senha, this.senha);
    }


    /**
     * Verifica se o login fornecido é igual ao login do usuário.
     * @return
     */
    public String getLogin() {
        return login;
    }

    /**
     * Seta o login do usuário.
     * @param login
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * Retorna a senha do usuário.
     * @return Senha do usuário.
     */
    public String getSenha() {
        return senha;
    }

    /**
     * Seta a senha do usuário.
     * @param senha
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * Retorna o nome do usuário.
     * @return Nome do usuário.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Seta o nome do usuário.
     * @param nome
     * @return Nome do usuário.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Retorna a lista de amigos do usuário.
     * @return Lista de amigos do usuário.
     */
    public ArrayList<String> getFriends() {
        return friends;
    }

    /**
     * Seta a lista de amigos do usuário.
     * @param friends
     */
    public void setFriends(ArrayList<String> friends) {
        this.friends = friends;
    }

    /**
     * Retorna a lista de solicitações de amizade do usuário.
     * @return Lista de solicitações de amizade do usuário.
     */
    public ArrayList<String> getSolicitacoesDeAmizade() {
        return solicitacoesDeAmizade;
    }

    /**
     * Seta a lista de solicitações de amizade do usuário.
     * @param solicitacoesDeAmizade
     */
    public void setSolicitacoesDeAmizade(ArrayList<String> solicitacoesDeAmizade) {
        this.solicitacoesDeAmizade = solicitacoesDeAmizade;
    }

    /**
     * Retorna o atributo do usuário.
     * @return Atributo do usuário.
     */
    @JsonAnyGetter
    public Map<String, String> getAtributos() {
        return atributos;
    }

    /**
     * Seta o atributo do usuário.
     * @param atributo
     * @param valor
     */
    @JsonAnySetter
    public void setAtributos(String atributo, String valor) {
        this.atributos.put(atributo, valor);
    }

    /**
     * Retorna a lista de mensagens na caixa de entrada do usuário.
     * @return Lista de mensagens na caixa de entrada do usuário.
     */
    public Queue<Recado> getCaixaMensagem() {
        return caixaMensagem;
    }

    /**
     * Seta a lista de mensagens na caixa de entrada do usuário.
     * @param caixaMensagem
     */
    public void setCaixaMensagem(Queue<Recado> caixaMensagem) {
        this.caixaMensagem = caixaMensagem;
    }

    /**
     * Adiciona um amigo à lista de amigos do usuário.
     * @param solicitacaoAmizade
     */
    public void adicionarAmigos(String solicitacaoAmizade){
        this.friends.add(solicitacaoAmizade);
        this.solicitacoesDeAmizade.remove(solicitacaoAmizade);
    }

    /**
     * Recebe uma mensagem na caixa de entrada do usuário.
     * @param recado
     */
    public void receberMensagem(Recado recado){ 
        this.caixaMensagem.add(recado);
    }

    /**
     * Adiciona uma mensagem à comunidade do usuário.
     */
    public Queue<String> getMensagensComunidade() { return mensagensComunidade; }

    /**
     * Seta a lista de mensagens na comunidade do usuário.
     * @param mensagensComunidade
     */
    public void setMensagensComunidade(Queue<String> mensagensComunidade) { this.mensagensComunidade = mensagensComunidade; }

    /**
     * Adiciona um fã à lista de fãs do usuário.
     * @param loginFa
     */
    public void adicionarFa(String loginFa) {
        if (!fas.contains(loginFa)) {
            fas.add(loginFa);
        }
    }

    /**
     * Adiciona um paquera à lista de paqueras do usuário.
     * @param loginPaquera
     */
    public void adicionarPaquera(String loginPaquera) {
        if (!paqueras.contains(loginPaquera)) {
            paqueras.add(loginPaquera);
        }
    }

    /**
     * Adiciona um inimigo à lista de inimigos do usuário.
     * @param loginInimigo
     */
    public void adicionarInimigo(String loginInimigo) {
        if (!inimigos.contains(loginInimigo)) {
            inimigos.add(loginInimigo);
        }
    }

    /**
     * Retorna a lista de fãs do usuário.
     * @return Lista de fãs do usuário.
     */
    public List<String> getFas() {
        return fas;
    }

    /**
     * Retorna a lista de paqueras do usuário.
     * @return Lista de paqueras do usuário.
     */
    public List<String> getPaqueras() {
        return paqueras;
    }

    /**
     * Retorna a lista de inimigos do usuário.
     * @return Lista de inimigos do usuário.
     */
    public List<String> getInimigos() {
        return inimigos;
    }
}
