package br.ufal.ic.p2.jackut.service;

import br.ufal.ic.p2.jackut.Exceptions.*;
import br.ufal.ic.p2.jackut.models.Usuario;
import br.ufal.ic.p2.jackut.repository.SistemaRepository;
import java.util.*;

/**
 * Classe respons�vel por gerenciar os usu�rios do sistema.
 * Esta classe fornece m�todos para criar, editar, remover e gerenciar amigos, �dolos e paqueras dos usu�rios.
 */
public class UsuarioService {
    private final SistemaRepository repo;
    private final Map<String, Usuario> usuarios;

    /**
     * Construtor da classe UsuarioService.
     * Inicializa o reposit�rio de sistema e carrega os usu�rios armazenados.
     */
    public UsuarioService() {
        this.repo = new SistemaRepository();
        this.usuarios = new HashMap<>();
        carregar();
    }

    /**
     * Limpa todos os usu�rios armazenados no sistema.
     */
    public void zerar() {
        usuarios.clear();
        salvar();
    }

    /**
     * Carrega os usu�rios a partir do reposit�rio.
     * Se o reposit�rio n�o existir, n�o faz nada.
     */
    public void carregar() {
        try {
            for (Usuario u : repo.carregarUsuarios()) {
                usuarios.put(u.getLogin(), u);
            }
        } catch (Exception e) {
            throw new RuntimeException("Falha ao carregar usu�rios", e);
        }
    }

    /**
     * Salva os usu�rios no reposit�rio.
     * Se ocorrer um erro durante o salvamento, lan�a uma exce��o.
     */
    public void salvar() {
        try {
            repo.salvarUsuarios(new ArrayList<>(usuarios.values()));
        } catch (Exception e) {
            throw new RuntimeException("Falha ao salvar usu�rios", e);
        }
    }

    /**
     * Cria um novo usu�rio com os dados fornecidos.
     * Se o login ou senha forem inv�lidos, ou se o usu�rio j� existir, lan�a uma exce��o.
     *
     * @param login O login do usu�rio.
     * @param senha A senha do usu�rio.
     * @param nome  O nome do usu�rio.
     */
    public void criarUsuario(String login, String senha, String nome) {
        if (login == null || login.trim().isEmpty())
            throw new LoginInvalidoException();
        if (senha == null || senha.trim().isEmpty())
            throw new SenhaInvalidaException();
        if (usuarios.containsKey(login))
            throw new ContaJaExisteException();
        Usuario u = new Usuario(nome, login, senha);
        usuarios.put(login, u);
        salvar();
    }

    /**
     * Retorna o atributo de um usu�rio.
     * @param login
     * @param atributo
     * @return
     */
    public String getAtributo(String login, String atributo) {
        Usuario u = usuarios.get(login);
        if (u == null) {
            throw new UsuarioNaoCadastradoException();
        }
        if ("nome".equals(atributo)) {
            return u.getNome();
        } else if ("senha".equals(atributo)) {
            return u.getSenha();
        }
        String valor = u.getAtributos().get(atributo);
        if (valor == null) {
            throw new AtributoNaoPreenchidoException();
        }
        return valor;
    }

    /**
     * Edita o perfil do usu�rio com os dados fornecidos.
     * Se o login n�o existir ou o novo login j� estiver em uso, lan�a uma exce��o.
     *
     * @param login    O login do usu�rio a ser editado.
     * @param atributo O atributo a ser editado (nome, senha, etc.).
     * @param conteudo O novo valor para o atributo.
     */
    public void editarPerfil(String login, String atributo, String conteudo) {
        Usuario u = usuarios.get(login);
        if (u == null)
            throw new UsuarioNaoCadastradoException();
        switch (atributo) {
            case "nome":
                u.setNome(conteudo);
                break;
            case "senha":
                u.setSenha(conteudo);
                break;
            case "login":
                if (usuarios.containsKey(conteudo))
                    throw new LoginJaExisteException();
                usuarios.remove(u.getLogin());
                u.setLogin(conteudo);
                usuarios.put(conteudo, u);
                break;
            default:
                u.setAtributos(atributo, conteudo);
        }
        salvar();
    }

    /**
     * Remove um usu�rio do sistema.
     * Se o usu�rio n�o existir, lan�a uma exce��o.
     *
     * @param login O login do usu�rio a ser removido.
     */
    public void removerUsuario(String login) {
        if (usuarios.remove(login) == null)
            throw new UsuarioNaoCadastradoException();
        salvar();
    }

    /**
     * Adiciona um amigo ao usu�rio.
     * Se o usu�rio ou o amigo n�o existirem, ou se j� forem amigos, lan�a uma exce��o.
     *
     * @param login      O login do usu�rio.
     * @param amigoLogin O login do amigo a ser adicionado.
     */
    public void adicionarAmigo(String login, String amigoLogin) {
        Usuario u = usuarios.get(login);
        Usuario f = usuarios.get(amigoLogin);
        if (u == null || f == null)
            throw new UsuarioNaoCadastradoException();;
        if (login.equals(amigoLogin))
            throw new UsuarioMesmoAmigoException();
        if (u.getFriends().contains(amigoLogin))
            throw new UsuarioJaAmigoException();
        if (u.getInimigos().contains(amigoLogin))
        {
            throw new FuncaoInvalidaException(f.getNome());
        }
        if (u.getSolicitacoesDeAmizade().contains(amigoLogin)) {
            u.adicionarAmigos(amigoLogin);
            f.adicionarAmigos(login);
        } else {
            if (f.getSolicitacoesDeAmizade().contains(login))
                throw new AmizadePendenteException();
            f.getSolicitacoesDeAmizade().add(login);
        }
        salvar();
    }

    /**
     * Verifica se dois usu�rios s�o amigos.
     * Se algum dos usu�rios n�o existir, lan�a uma exce��o.
     *
     * @param u1 O login do primeiro usu�rio.
     * @param u2 O login do segundo usu�rio.
     * @return true se os usu�rios forem amigos, false caso contr�rio.
     */
    public boolean ehAmigo(String u1, String u2) {
        Usuario usuario1 = usuarios.get(u1);
        Usuario usuario2 = usuarios.get(u2);
        if (usuario1 == null || usuario2 == null)
            throw new UsuarioNaoCadastradoException();;
        return usuario1.getFriends().contains(u2) && usuario2.getFriends().contains(u1);
    }

    /**
     * Retorna os amigos de um usu�rio.
     * Se o usu�rio n�o existir, lan�a uma exce��o.
     *
     * @param login O login do usu�rio.
     * @return Uma string com os logins dos amigos do usu�rio.
     */
    public String getAmigos(String login) {
        Usuario u = usuarios.get(login);
        if (u == null)
            throw new UsuarioNaoCadastradoException();;
        return "{" + String.join(",", u.getFriends()) + "}";
    }

    /**
     * Adiciona um �dolo ao usu�rio.
     * Se o usu�rio ou o �dolo n�o existirem, ou se o usu�rio tentar adicionar a si mesmo como �dolo, lan�a uma exce��o.
     *
     * @param login      O login do usu�rio.
     * @param idoloLogin O login do �dolo a ser adicionado.
     */
    public void adicionarIdolo(String login, String idoloLogin) {
        Usuario u    = usuarios.get(login);
        Usuario idol = usuarios.get(idoloLogin);
        if (u == null || idol == null)
            throw new UsuarioNaoCadastradoException();
        if (login.equals(idoloLogin))
            throw new UsuarioNaoPodeSerFaDeSiMesmoException();
        if (u.getInimigos().contains(idoloLogin))
            throw new FuncaoInvalidaException(idol.getNome());
        if (idol.getFas().contains(login))
            throw new UsuarioJaAdicionadoComoIdoloException();
        idol.adicionarFa(login);


        salvar();
    }

    /**
     * Verifica se um usu�rio � �dolo de outro usu�rio.
     * Se o usu�rio ou o �dolo n�o existirem, lan�a uma exce��o.
     *
     * @param login      O login do usu�rio.
     * @param idoloLogin O login do �dolo.
     * @return true se o usu�rio for �dolo do outro, false caso contr�rio.
     */
    public boolean ehIdolo(String login, String idoloLogin) {
        Usuario idol = usuarios.get(idoloLogin);
        if (idol == null)
            throw new UsuarioNaoCadastradoException();
        // retorna true se eu estiver na lista de f�s do �dolo
        return idol.getFas().contains(login);
    }

    /**
     * Retorna os �dolos de um usu�rio.
     * Se o usu�rio n�o existir, lan�a uma exce��o.
     *
     * @param login O login do usu�rio.
     * @return Uma string com os logins dos �dolos do usu�rio.
     */
    public String getIdolos(String login) {
        Usuario u = usuarios.get(login);
        if (u == null)
            throw new UsuarioNaoCadastradoException();
        // aqui getFas mant�m a sem�ntica de ?quem s�o meus f�s?
        return "{" + String.join(",", u.getFas()) + "}";
    }

    /**
     * Adiciona uma paquera ao usu�rio.
     * Se o usu�rio ou a paquera n�o existirem, ou se o usu�rio tentar adicionar a si mesmo como paquera, lan�a uma exce��o.
     *
     * @param login        O login do usu�rio.
     * @param paqueraLogin O login da paquera a ser adicionada.
     */
    public void adicionarPaquera(String login, String paqueraLogin) {
        Usuario u = usuarios.get(login);
        Usuario p = usuarios.get(paqueraLogin);
        if (u == null || p == null)
            throw new UsuarioNaoCadastradoException();
        if (u.getInimigos().contains(paqueraLogin))
            throw new FuncaoInvalidaException(p.getNome());
        // self-check
        if (login.equals(paqueraLogin))
            throw new UsuarioNaoPodeSerPaqueradeSiMesmoException();
        // duplicidade
        if (u.getPaqueras().contains(paqueraLogin))
            throw new UsuarioJaAdicionadoComoPaqueraException();
        u.adicionarPaquera(paqueraLogin);
        salvar();
    }


    /**
     * Verifica se um usu�rio � paquera de outro usu�rio.
     * Se o usu�rio ou a paquera n�o existirem, lan�a uma exce��o.
     *
     * @param login        O login do usu�rio.
     * @param paqueraLogin O login da paquera.
     * @return true se o usu�rio for paquera do outro, false caso contr�rio.
     */
    public boolean ehPaquera(String login, String paqueraLogin) {
        Usuario u = usuarios.get(login);
        if (u == null)
            throw new UsuarioNaoCadastradoException();;
        return u.getPaqueras().contains(paqueraLogin);
    }


    /**
     * Retorna os paqueras de um usu�rio.
     * Se o usu�rio n�o existir, lan�a uma exce��o.
     *
     * @param login O login do usu�rio.
     * @return Uma string com os logins dos paqueras do usu�rio.
     */
    public String getPaqueras(String login) {
        Usuario u = usuarios.get(login);
        if (u == null)
            throw new UsuarioNaoCadastradoException();;
        return "{" + String.join(",", u.getPaqueras()) + "}";
    }

    /**
     * Adiciona um inimigo ao usu�rio.
     * Se o usu�rio ou o inimigo n�o existirem, ou se o usu�rio tentar adicionar a si mesmo como inimigo, lan�a uma exce��o.
     *
     * @param login        O login do usu�rio.
     * @param inimigoLogin O login do inimigo a ser adicionado.
     */
    public void adicionarInimigo(String login, String inimigoLogin) {
        Usuario u = usuarios.get(login);
        Usuario i = usuarios.get(inimigoLogin);
        if (u == null || i == null)
            throw new UsuarioNaoCadastradoException();
        if (login.equals(inimigoLogin))
            throw new UsuarioNaoPodeSerInimigoDeSiMesmoException();
        if (u.getInimigos().contains(inimigoLogin))
            throw new UsuarioJaAdicionadoComoInimigoException();
        u.adicionarInimigo(inimigoLogin);
        i.adicionarInimigo(login);
        salvar();
    }

    /**
     * Retorna os inimigos de um usu�rio.
     *
     * @param login O login do usu�rio.
     * @return Uma lista com os logins dos inimigos do usu�rio.
     */
    public List<String> getInimigos(String loginDestinatario) {
        Usuario u = usuarios.get(loginDestinatario);
        if (u == null)
            throw new UsuarioNaoCadastradoException();
        return u.getInimigos();
    }
}