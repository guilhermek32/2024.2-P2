package br.ufal.ic.p2.jackut.service;

import br.ufal.ic.p2.jackut.Exceptions.LoginOuSenhaInvalidosException;
import br.ufal.ic.p2.jackut.Exceptions.UsuarioNaoCadastradoException;


/** * Classe respons�vel por validar sess�es de usu�rios.
 * Utiliza o servi�o de sess�o para verificar a validade da sess�o.
 */
public class SessaoValidator {
    private final SessaoService sessaoService;

    /**
     * Construtor da classe SessaoValidator.
     * Inicializa o servi�o de sess�o.
     *
     * @param sessaoService Servi�o de gerenciamento de sess�es.
     */
    public SessaoValidator(SessaoService sessaoService) {
        this.sessaoService = sessaoService;
    }

    /**
     * Valida a sess�o do usu�rio.
     * Se a sess�o for v�lida, retorna o login do usu�rio.
     * Caso contr�rio, lan�a uma exce��o de usu�rio n�o cadastrado.
     *
     * @param sessionId ID da sess�o a ser validada.
     * @return O login do usu�rio associado � sess�o.
     * @throws UsuarioNaoCadastradoException Se a sess�o n�o for v�lida.
     */
    public String validarSessao(String sessionId) {
        String login;
        try {
            login = sessaoService.getLoginPorSessao(sessionId);
        } catch (LoginOuSenhaInvalidosException e) {
            throw new UsuarioNaoCadastradoException();
        }
        return login;
    }
}
