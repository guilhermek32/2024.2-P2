package br.ufal.ic.p2.jackut.Facade;


/**
 * Interface que define os m�todos do sistema Jackut.
 */
public interface IFacade {

    /**
     * Zera o sistema, removendo todos os dados.
     */
    // Controle do sistema
    void zerarSistema();
    void carregarSistema();
    void encerrarSistema();


    /**
     * Cria um novo usu�rio no sistema.
     *
     * @param login  O login do usu�rio.
     * @param senha  A senha do usu�rio.
     * @param nome   O nome do usu�rio.
     */
    // Gerenciamento de usu�rio
    void criarUsuario(String login, String senha, String nome);

    /**
     * Retorna o atributo de um usu�rio.
     * @param login
     * @param atributo
     * @return Atributo do usu�rio.
     */
    String getAtributoUsuario(String login, String atributo);

    /**
     * Edita o perfil de um usu�rio.
     *
     * @param sessionId O ID da sess�o do usu�rio.
     * @param atributo  O atributo a ser editado.
     * @param conteudo  O novo conte�do do atributo.
     */
    void editarPerfil(String sessionId, String atributo, String conteudo);

    /**
     * Remove um usu�rio do sistema.
     * @param sessionId
     */
    void removerUsuario(String sessionId);

    /**
     * Abre uma sess�o para um usu�rio.
     * @param login
     * @param senha
     * @return ID da sess�o.
     */
    String abrirSessao(String login, String senha);

    /**
     * Adiciona um amigo ao dono da sess�o.
     * @param sessionId
     * @param amigo
     */
    void adicionarAmigo(String sessionId, String amigo);

    /**
     * Verifica se um usu�rio � amigo de outro.
     * @param usuarioVerificador
     * @param usuarioVerificado
     * @return true se forem amigos, false caso contr�rio.
     */
    boolean ehAmigo(String usuarioVerificador, String usuarioVerificado);

    /**
     * Retorna os amigos de um usu�rio.
     * @param login
     * @return Lista de amigos do usu�rio.
     */
    String getAmigos(String login);


    /**
     * Envia um recado para outro usu�rio.
     * @param sessionId
     * @param destinatario
     * @param mensagem
     */
    void enviarRecado(String sessionId, String destinatario, String mensagem);

    /**
     * L� um recado do dono da sess�o.
     * @param sessionId
     * @return Texto do recado lido.
     */
    String lerRecado(String sessionId);


    /**
     * Cria uma nova comunidade.
     * @param sessionId
     * @param nome
     * @param descricao
     */
    void criarComunidade(String sessionId, String nome, String descricao);

    /**
     * Adiciona um usu�rio a uma comunidade existente.
     * @param sessionId
     * @param nome
     */
    void adicionarComunidade(String sessionId, String nome);

    /**
     * Retorna a descri��o da comunidade.
     * @param nome
     * @return Descri��o da comunidade.
     */
    String getDescricaoComunidade(String nome);

    /**
     * Retorna o dono da comunidade.
     * @param nome
     * @return Dono da comunidade.
     */
    String getDonoComunidade(String nome);

    /**
     * Retorna os membros da comunidade.
     * @param nome
     * @return Membros da comunidade.
     */
    String getMembrosComunidade(String nome);

    /**
     * Retorna as comunidades de um usu�rio.
     * @param login
     * @return Comunidades do usu�rio.
     */
    String getComunidades(String login);

    /**
     * Envia uma mensagem para todos os membros de uma comunidade.
     * @param sessionId
     * @param nomeComunidade
     * @param texto
     */
    void enviarMensagemComunidade(String sessionId, String nomeComunidade, String texto);

    /**
     * L� uma mensagem da comunidade do dono da sess�o.
     * @param sessionId
     * @return Mensagem lida.
     */
    String lerMensagemComunidade(String sessionId);

    /**
     * Adiciona um f� ao dono da sess�o.
     * @param sessionId
     * @param idoloLogin
     */
    void adicionarIdolo(String sessionId, String idoloLogin);

    /**
     * Verifica se um usu�rio � f� de outro.
     * @param login
     * @param idoloLogin
     * @return true se forem f�s, false caso contr�rio.
     */
    boolean ehFa(String login, String idoloLogin);

    /**
     * Retorna os f�s de um usu�rio.
     * @param login
     * @return Lista de f�s do usu�rio.
     */
    String getFas(String login);

    /**
     * Adiciona um paquera ao dono da sess�o.
     * @param sessionId
     * @param paqueraLogin
     */
    void adicionarPaquera(String sessionId, String paqueraLogin);

    /**
     * Verifica se um usu�rio � paquera de outro.
     * @param sessionId
     * @param paqueraLogin
     * @return true se forem paqueras, false caso contr�rio.
     */
    boolean ehPaquera(String sessionId, String paqueraLogin);

    /**
     * Retorna os paqueras do dono da sess�o.
     * @param sessionId
     * @return Lista de paqueras do usu�rio.
     */
    String getPaqueras(String sessionId);

    /**
     * Adiciona um inimigo ao dono da sess�o.
     * @param sessionId
     * @param inimigoLogin
     */
    void adicionarInimigo(String sessionId, String inimigoLogin);

    /**
     * Envia uma mensagem a comunidade
     * @param sessionId
     * @param nomeComunidade
     * @param mensagem
     */
    void enviarMensagem(String sessionId, String nomeComunidade, String mensagem);

    /**
     * L� uma mensagem do dono da sess�o.
     * @param sessionId
     * @return Mensagem lida.
     */
    String lerMensagem(String sessionId);

}