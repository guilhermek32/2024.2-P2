package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada ao adicionar um usu�rio como inimigo, mas ele j� est� adicionado.
 */
public class UsuarioJaAdicionadoComoInimigoException extends RuntimeException {
    public UsuarioJaAdicionadoComoInimigoException() {
        super("Usu�rio j� est� adicionado como inimigo.");
    }
}
