
// src/main/java/br/ufal/ic/p2/jackut/service/MensagemService.java
package br.ufal.ic.p2.jackut.service;

import br.ufal.ic.p2.jackut.Exceptions.*;
import br.ufal.ic.p2.jackut.exceptions.ComunidadeNaoExisteException;
import br.ufal.ic.p2.jackut.models.Recado;
import br.ufal.ic.p2.jackut.models.Usuario;
import br.ufal.ic.p2.jackut.utils.JsonUtil;

import java.io.File;
import java.util.*;


/**
 * Classe respons�vel por gerenciar o envio e recebimento de mensagens entre usu�rios e comunidades.
 * As mensagens s�o armazenadas em arquivos JSON.
 */
public class MensagemService {
    private static final String RECADOS_JSON = "recados.json";
    private static final String MSG_COMMUNIDADE_JSON = "mensagens_comunidade.json";

    private final UsuarioService usuarioService;
    private final SessaoService sessaoService;
    private final ComunidadeService comunidadeService;
    private final Map<String, List<Recado>> recadosPorUsuario;
    private final Map<String, List<Recado>> mensagensPorComunidade;

    /**
     * Construtor da classe MensagemService.
     * Inicializa os servi�os necess�rios e carrega as mensagens armazenadas.
     *
     * @param usuarioService   Servi�o de gerenciamento de usu�rios.
     * @param sessaoService    Servi�o de gerenciamento de sess�es.
     * @param comunidadeService Servi�o de gerenciamento de comunidades.
     */
    public MensagemService(UsuarioService usuarioService, SessaoService sessaoService, ComunidadeService comunidadeService) {
        this.usuarioService = usuarioService;
        this.sessaoService = sessaoService;
        this.comunidadeService = comunidadeService;
        this.recadosPorUsuario = new HashMap<>();
        this.mensagensPorComunidade = new HashMap<>();
        carregar();
    }

    /**
     * Limpa todas as mensagens e recados armazenados.
     */
    public void zerar() {
        recadosPorUsuario.clear();
        mensagensPorComunidade.clear();
        salvar();
    }

    /**
     * Carrega as mensagens de recados e mensagens de comunidade a partir dos arquivos JSON.
     * Se os arquivos n�o existirem, n�o faz nada.
     */
    @SuppressWarnings("unchecked")
    public void carregar() {
        try {
            List<Recado> list = JsonUtil.fromFile(new File(RECADOS_JSON), List.class);
            for (Recado r : list) {
                recadosPorUsuario.computeIfAbsent(r.getRemetente(), k -> new ArrayList<>()).add(r);
            }
        } catch (Exception e) {
            // arquivo pode n�o existir
        }
        try {
            List<Recado> list = JsonUtil.fromFile(new File(MSG_COMMUNIDADE_JSON), List.class);
            for (Recado r : list) {
                mensagensPorComunidade
                        .computeIfAbsent(r.getRemetente(), k -> new ArrayList<>())
                        .add(r);
            }
        } catch (Exception e) { }
    }

    /**
     * Salva as mensagens de recados e mensagens de comunidade nos arquivos JSON.
     * Se ocorrer um erro durante a grava��o, lan�a uma exce��o.
     */
    public void salvar() {
        try {
            List<Recado> allRecados = new ArrayList<>();
            recadosPorUsuario.values().forEach(allRecados::addAll);
            JsonUtil.toFile(new File(RECADOS_JSON), allRecados);

            List<Recado> allMsgs = new ArrayList<>();
            mensagensPorComunidade.values().forEach(allMsgs::addAll);
            JsonUtil.toFile(new File(MSG_COMMUNIDADE_JSON), allMsgs);
        } catch (Exception e) {
            throw new RuntimeException("Falha ao salvar mensagens", e);
        }
    }

    /**
     * Envia um recado para um usu�rio espec�fico.
     *
     * @param sessionId        ID da sess�o do remetente.
     * @param loginDestinatario Login do destinat�rio.
     * @param texto            Texto do recado.
     */
    public void enviarRecado(String sessionId, String loginDestinatario, String texto) {
        // valida sess�o e destinat�rio
        String remetente = sessaoService.getLoginPorSessao(sessionId);

        List<String> inimigosDoDest = usuarioService.getInimigos(loginDestinatario);
        if (inimigosDoDest.contains(remetente)) {
            String nomeDest = usuarioService.getAtributo(loginDestinatario, "nome");
            throw new FuncaoInvalidaException(nomeDest);
        }
        Recado r = new Recado(remetente, texto);
        recadosPorUsuario
                .computeIfAbsent(loginDestinatario, k -> new ArrayList<>())
                .add(r);
        salvar();
    }


    /**
     * L� um recado do usu�rio atual.
     *
     * @param sessionId ID da sess�o do usu�rio.
     * @return Texto do recado lido.
     */
    public String lerRecado(String sessionId) {
        String login;
        try {
            // valida sess�o
            login = sessaoService.getLoginPorSessao(sessionId);
        } catch (LoginOuSenhaInvalidosException e) {
            throw new UsuarioNaoCadastradoException();
        }

        List<Recado> list = recadosPorUsuario.getOrDefault(login, new ArrayList<>());
        if (list.isEmpty()) {
            throw new NaoHaRecadosException();
        }

        Recado r = list.remove(0);
        salvar();
        return r.getMensagem();
    }


    /**
     * Envia uma mensagem para todos os membros de uma comunidade.
     *
     * @param sessionId      ID da sess�o do remetente.
     * @param nomeComunidade Nome da comunidade.
     * @param texto          Texto da mensagem.
     */
    public void enviarMensagemComunidade(String sessionId, String nomeComunidade, String texto) {
        String remetente = sessaoService.getLoginPorSessao(sessionId);
        comunidadeService.getDescricaoComunidade(nomeComunidade);

        String raw = comunidadeService.getMembrosComunidade(nomeComunidade);
        List<String> membros = Arrays.stream(raw.replaceAll("[{}]", "").split(","))
                .filter(s -> !s.isBlank())
                .toList();

        for (String membro : membros) {
            Recado r = new Recado(membro, texto);
            mensagensPorComunidade
                    .computeIfAbsent(membro, k -> new ArrayList<>())
                    .add(r);
        }
        salvar();
    }



    /**
     * Adiciona um paquera ao dono da sess�o e envia recados caso ambos sejam paqueras um do outro.
     */
    public void adicionarPaqueraESendRecados(String sessionId, String paqueraLogin) {
        String login = sessaoService.getLoginPorSessao(sessionId);
        usuarioService.adicionarPaquera(login, paqueraLogin);

        if (usuarioService.ehPaquera(paqueraLogin, login)) {
            String nomeLogin = usuarioService.getAtributo(login, "nome");
            String nomePaquera = usuarioService.getAtributo(paqueraLogin, "nome");

            // Envia recado para o paquera
            enviarRecado(sessionId, paqueraLogin, String.format("%s � seu paquera - Recado do Jackut.", nomeLogin));

            // Envia recado para o dono da sess�o
            enviarRecado(sessionId, login, String.format("%s � seu paquera - Recado do Jackut.", nomePaquera));
        }
    }


    /**
     * L� uma mensagem da comunidade do usu�rio atual.
     *
     * @param sessionId ID da sess�o do usu�rio.
     * @return Texto da mensagem lida.
     */
    public String lerMensagemComunidade(String sessionId) {
        String login = sessaoService.getLoginPorSessao(sessionId);
        List<Recado> fila = mensagensPorComunidade.getOrDefault(login, new ArrayList<>());
        if (fila.isEmpty()) {
            return "{}";
        }
        Recado r = fila.remove(0);
        if (fila.isEmpty()) {
            mensagensPorComunidade.remove(login);
        }
        salvar();
        return r.getMensagem();
    }

    /**
     * Remove um usu�rio e suas mensagens de recados e mensagens de comunidade.
     *
     * @param login Login do usu�rio a ser removido.
     */
    public void removerUsuario(String login) {
        recadosPorUsuario.remove(login);
        for (List<Recado> lista : recadosPorUsuario.values()) {
            lista.removeIf(r -> r.getRemetente().equals(login));
        }
        mensagensPorComunidade.remove(login);
        for (List<Recado> lista : mensagensPorComunidade.values()) {
            lista.removeIf(r -> r.getRemetente().equals(login));
        }
        salvar();
    }
}
