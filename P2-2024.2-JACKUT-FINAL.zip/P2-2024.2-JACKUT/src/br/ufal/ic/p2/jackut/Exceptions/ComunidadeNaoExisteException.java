package br.ufal.ic.p2.jackut.exceptions;

/**
 * Exce��o lan�ada quando uma comunidade n�o existe.
 */
public class ComunidadeNaoExisteException extends RuntimeException {
  public ComunidadeNaoExisteException() {super("Comunidade n�o existe.");
  }
}