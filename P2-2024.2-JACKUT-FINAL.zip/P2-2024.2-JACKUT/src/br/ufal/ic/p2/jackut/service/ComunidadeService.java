package br.ufal.ic.p2.jackut.service;


import br.ufal.ic.p2.jackut.Exceptions.*;

import br.ufal.ic.p2.jackut.exceptions.ComunidadeNaoExisteException;
import br.ufal.ic.p2.jackut.models.Comunidade;
import br.ufal.ic.p2.jackut.utils.JsonUtil;
import java.io.File;
import java.util.*;

/**
 * Classe respons�vel por gerenciar comunidades no sistema.
 * As comunidades s�o armazenadas em um arquivo JSON.
 */
public class ComunidadeService {
    private static final String COMUNIDADES_JSON = "comunidades.json";
    private final SessaoService sessaoService;
    private final Map<String, Comunidade> comunidades;
    private final Map<String, List<String>> comunidadesPorUsuario = new HashMap<>();

    /**
     * Construtor da classe ComunidadeService.
     * Inicializa o servi�o de sess�es e carrega as comunidades armazenadas.
     *
     * @param usuarioService Servi�o de gerenciamento de usu�rios.
     * @param sessaoService  Servi�o de gerenciamento de sess�es.
     */
    public ComunidadeService(UsuarioService usuarioService, SessaoService sessaoService) {
        this.sessaoService = sessaoService;
        this.comunidades = new HashMap<>();
        carregar();
    }

    /**
     * Limpa todas as comunidades armazenadas.
     */
    public void zerar() {
        comunidades.clear();
        comunidadesPorUsuario.clear();
        salvar();
    }

    /**
     * Carrega as comunidades a partir do arquivo JSON.
     * Se o arquivo n�o existir, n�o faz nada.
     */
    public void carregar() {
        try {
            List<Comunidade> list = JsonUtil.fromFile(new File(COMUNIDADES_JSON), List.class);
            for (Comunidade c : list) {
                comunidades.put(c.getNome(), c);
            }
        } catch (Exception e) {
            // arquivo pode n�o existir
        }
    }

    /**
     * Salva as comunidades no arquivo JSON.
     */
    public void salvar() {
        try {
            JsonUtil.toFile(new File(COMUNIDADES_JSON), new ArrayList<>(comunidades.values()));
        } catch (Exception e) {
            throw new RuntimeException("Falha ao salvar comunidades", e);
        }
    }

    /**
     * Cria uma nova comunidade.
     *
     * @param sessionId  ID da sess�o do usu�rio que est� criando a comunidade.
     * @param nome       Nome da comunidade.
     * @param descricao  Descri��o da comunidade.
     */
    public void criarComunidade(String sessionId, String nome, String descricao) {
        String dono = sessaoService.getLoginPorSessao(sessionId);
        if (comunidades.containsKey(nome))
            throw new ComunidadeJaExisteException();
        Comunidade c = new Comunidade(nome, descricao, dono);
        c.addMembro(dono);
        comunidades.put(nome, c);
        // registra o join do dono
        comunidadesPorUsuario
                .computeIfAbsent(dono, k -> new ArrayList<>())
                .add(nome);
        salvar();
    }

    /**
     * Adiciona um usu�rio a uma comunidade existente.
     *
     * @param sessionId ID da sess�o do usu�rio que est� se juntando � comunidade.
     * @param nome      Nome da comunidade.
     */
    public void adicionarComunidade(String sessionId, String nome) {
        String usuario = sessaoService.getLoginPorSessao(sessionId);
        Comunidade c = comunidades.get(nome);
        if (c == null)
            throw new br.ufal.ic.p2.jackut.exceptions.ComunidadeNaoExisteException();
        if (c.getMembros().contains(usuario))
            throw new UsuarioJaMembroDaComunidade();
        c.addMembro(usuario);
        // **aqui faltava**: registrar o join do usu�rio
        comunidadesPorUsuario
                .computeIfAbsent(usuario, k -> new ArrayList<>())
                .add(nome);
        salvar();
    }

    /**
     * Retorna a descri��o da comunidade.
     * @param nome
     * @return Descri��o da comunidade.
     */
    public String getDescricaoComunidade(String nome) {
        Comunidade c = comunidades.get(nome);
        if (c == null)
            throw new ComunidadeNaoExisteException();
        return c.getDescricaoComunidade();
    }

    /**
     * Retorna o dono da comunidade.
     * @param nome
     * @return Dono da comunidade.
     */
    public String getDonoComunidade(String nome) {
        Comunidade c = comunidades.get(nome);
        if (c == null)
            throw new br.ufal.ic.p2.jackut.exceptions.ComunidadeNaoExisteException();
        return c.getDonoComunidade();
    }

    /**
     * Retorna os membros da comunidade.
     * @param nome
     * @return Membros da comunidade.
     */
    public String getMembrosComunidade(String nome) {
        Comunidade c = comunidades.get(nome);
        if (c == null)
            throw new br.ufal.ic.p2.jackut.exceptions.ComunidadeNaoExisteException();
        return "{" + String.join(",", c.getMembros()) + "}";
    }

    /**
     * Remove um usu�rio de todas as comunidades.
     * Al�m disso, remove a comunidade se o usu�rio for o dono.
     * @param login
     */
    public void removerUsuario(String login) {
        comunidades.values().removeIf(c -> c.getDonoComunidade().equals(login));

        for (Comunidade c : comunidades.values()) {
            c.getMembros().remove(login);
        }

        comunidadesPorUsuario.clear();
        for (Comunidade c : comunidades.values()) {
            for (String m : c.getMembros()) {
                comunidadesPorUsuario
                        .computeIfAbsent(m, k -> new ArrayList<>())
                        .add(c.getNome());
            }
        }

        salvar();
    }

    /**
     * Retorna as comunidades de um usu�rio.
     * @param login
     * @return Comunidades do usu�rio, ou uma string vazia se n�o houver.
     */
    public String getComunidades(String login) {
        // agora usa a lista de join preservada
        List<String> lista = comunidadesPorUsuario
                .getOrDefault(login, Collections.emptyList());
        return "{" + String.join(",", lista) + "}";
    }
}