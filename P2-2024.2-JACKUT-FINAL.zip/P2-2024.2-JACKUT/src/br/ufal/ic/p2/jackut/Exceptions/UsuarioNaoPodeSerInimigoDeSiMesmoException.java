package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio tenta se tornar inimigo de si mesmo.
 */
public class UsuarioNaoPodeSerInimigoDeSiMesmoException extends RuntimeException {
    public UsuarioNaoPodeSerInimigoDeSiMesmoException() {
        super("Usu�rio n�o pode ser inimigo de si mesmo.");
    }
}
