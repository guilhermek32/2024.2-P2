// src/main/java/br/ufal/ic/p2/jackut/utils/JsonUtil.java
package br.ufal.ic.p2.jackut.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class JsonUtil {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static <T> T fromFile(File file, Class<T> clazz) throws Exception {
        return MAPPER.readValue(file, clazz);
    }

    public static void toFile(File file, Object obj) throws Exception {
        MAPPER.writerWithDefaultPrettyPrinter().writeValue(file, obj);
    }
}
