package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando uma usuario tenta adicionar um idolo novamente.
 */
public class UsuarioJaAdicionadoComoIdoloException extends RuntimeException {
    public UsuarioJaAdicionadoComoIdoloException() {
        super("Usu�rio j� est� adicionado como �dolo.");
    }
}
