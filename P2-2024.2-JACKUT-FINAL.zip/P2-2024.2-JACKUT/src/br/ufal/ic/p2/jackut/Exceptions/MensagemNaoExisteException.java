package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando n�o h� mensagens.
 */
public class MensagemNaoExisteException extends RuntimeException {
    public MensagemNaoExisteException() {
        super("N�o h� mensagens.");
    }
}
