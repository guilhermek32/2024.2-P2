package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando tenta-se adicionar um usu�rio como paquera, mas ele j� est� adicionado.
 */
public class UsuarioJaAdicionadoComoPaqueraException extends RuntimeException {
    public UsuarioJaAdicionadoComoPaqueraException() {super("Usu�rio j� est� adicionado como paquera.");}
}