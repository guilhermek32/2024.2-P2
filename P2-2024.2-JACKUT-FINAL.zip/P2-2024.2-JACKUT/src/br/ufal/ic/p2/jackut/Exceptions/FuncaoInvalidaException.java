package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o quando o usuario tenta enviar um recado a um inimigo.
 */
public class FuncaoInvalidaException extends RuntimeException {
    public FuncaoInvalidaException(String message) {
        super("Fun��o inv�lida: " + message + " � seu inimigo.");
    }
}
