package br.ufal.ic.p2.jackut.models;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa uma comunidade no sistema.
 */
public class Comunidade {
    private String nome;
    private String descricao;
    private String dono;
    private List<String> membros;

    /**
     * Construtor da classe Comunidade com par�metros.
     *
     * @param nome        Nome da comunidade.
     * @param descricao   Descri��o da comunidade.
     * @param dono        Dono da comunidade.
     */
    public Comunidade(String nome, String descricao, String dono) {
        this.nome = nome;
        this.descricao = descricao;
        this.dono = dono;
        this.membros = new ArrayList<>();
    }

    /**
     * Obt�m o nome da comunidade.
     * @return Nome da comunidade.
     */
    public String getNome() { return nome; }

    /**
     * Obt�m a descri��o da comunidade.
     * @return Descri��o da comunidade.
     */
    public String getDescricaoComunidade() { return descricao; }

    /**
     * Obt�m o dono da comunidade.
     * @return Dono da comunidade.
     */
    public String getDonoComunidade() { return dono; }

    /**
     * Seta o nome da comunidade.
     * @param nome
     */
    public void setNome(String nome) { this.nome = nome; }

    /**
     * Seta a descri��o da comunidade.
     * @param descricao
     */
    public void setDescricao(String descricao) { this.descricao = descricao; }

    /**
     * Seta o dono da comunidade.
     * @param dono
     */
    public void setDono(String dono) { this.dono = dono; }

    /**
     * Obt�m a lista de membros da comunidade.
     * @return Lista de membros da comunidade.
     */
    public List<String> getMembros() { return membros; }

    /**
     * Seta a lista de membros da comunidade.
     * @param membros
     */
    public void setMembros(List<String> membros) { this.membros = membros; }

    /**
     * Adiciona um membro � comunidade, caso ele n�o esteja nela.
     * @param membro
     */
    public void addMembro(String membro) {
        if (!membros.contains(membro)) {
            membros.add(membro);
        }
    }




}
