package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio tenta se adicionar como paquera de si mesmo.
 */
public class UsuarioNaoPodeSerPaqueradeSiMesmoException extends RuntimeException {
    public UsuarioNaoPodeSerPaqueradeSiMesmoException() { super("Usu�rio n�o pode ser paquera de si mesmo.");
    }
}
