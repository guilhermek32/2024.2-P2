package br.ufal.ic.p2.jackut.service;

import br.ufal.ic.p2.jackut.Exceptions.LoginInvalidoException;
import br.ufal.ic.p2.jackut.Exceptions.LoginOuSenhaInvalidosException;
import br.ufal.ic.p2.jackut.Exceptions.SenhaInvalidaException;
import br.ufal.ic.p2.jackut.Exceptions.UsuarioNaoCadastradoException;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Classe respons�vel por gerenciar as sess�es dos usu�rios.
 * As sess�es s�o tempor�rias e n�o persistem entre execu��es do programa.
 */
public class SessaoService {
    private final UsuarioService usuarioService;
    private final Map<String, String> sessoes;

    /**
     * Construtor da classe SessaoService.
     * Inicializa o servi�o de usu�rios e o mapa de sess�es.
     *
     * @param usuarioService Servi�o de gerenciamento de usu�rios.
     */
    public SessaoService(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
        this.sessoes = new HashMap<>();
    }

    /**
     * Limpa todas as sess�es ativas.
     */
    public void zerar() {
        sessoes.clear();
    }

    /**
     * Carrega as sess�es ativas.
     * Como as sess�es s�o tempor�rias, n�o h� persist�ncia.
     */
    public void carregar() {
        // sess�es s�o tempor�rias, n�o h� persist�ncia
    }

    /**
     * Abre sess�o para o usu�rio se login e senha conferirem.
     * @return token de sess�o
     */
    public String abrirSessao(String login, String senha) {
        String senhaArmazenada;
        try {
            // tenta obter a senha; se o login n�o existir, getAtributo j� lan�a UsuarioNaoCadastradoException
            senhaArmazenada = usuarioService.getAtributo(login, "senha");
        } catch (UsuarioNaoCadastradoException e) {
            // converte em erro gen�rico de login/senha
            throw new LoginOuSenhaInvalidosException();
        }

        // se a senha n�o bate, tamb�m erro gen�rico
        if (!senhaArmazenada.equals(senha)) {
            throw new LoginOuSenhaInvalidosException();
        }

        // login/senha v�lidos: gera sess�o
        String sessionId = UUID.randomUUID().toString();
        sessoes.put(sessionId, login);
        return sessionId;
    }


    /**
     * Recupera o login associado a uma sess�o ativa.
     */
    public String getLoginPorSessao(String sessionId) {
        String login = sessoes.get(sessionId);
        if (login == null) {
            throw new LoginOuSenhaInvalidosException();
        }
        return login;
    }

    /**
     * Retorna a sess�o ativa de um dado login.
     * �til para reusar o sessionId ao enviar recados de volta.
     */
    public String getSessionIdPorLogin(String login) {
        for (var entry : sessoes.entrySet()) {
            if (entry.getValue().equals(login)) {
                return entry.getKey();
            }
        }
        // se n�o achar, trata igual sess�o inv�lida
        throw new LoginOuSenhaInvalidosException();
    }



    /**
     * Encerra uma sess�o ativa.
     */
    public void encerrarSessao(String sessionId) {
        sessoes.remove(sessionId);
    }
}