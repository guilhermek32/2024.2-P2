package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio j� � membro de uma comunidade e tenta se cadastrar novamente.
 */
public class UsuarioJaMembroDaComunidade extends RuntimeException {
    public UsuarioJaMembroDaComunidade() {
        super("Usuario j� faz parte dessa comunidade.");
    }
}
